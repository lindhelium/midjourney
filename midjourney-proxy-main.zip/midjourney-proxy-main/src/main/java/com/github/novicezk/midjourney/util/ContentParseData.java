package com.github.novicezk.midjourney.util;

import lombok.Data;

@Data
public class ContentParseData {
	protected String prompt;
	protected String status;
}
