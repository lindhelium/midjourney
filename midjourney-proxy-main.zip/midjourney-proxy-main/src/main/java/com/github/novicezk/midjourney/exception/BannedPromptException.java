package com.github.novicezk.midjourney.exception;

public class BannedPromptException extends Exception {

	public BannedPromptException(String message) {
		super(message);
	}
}
